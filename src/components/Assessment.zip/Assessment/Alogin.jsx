import React, { useState } from "react";
import { collection, addDoc, Timestamp } from "firebase/firestore";
import { db } from "../../firebaseConfig";
import { useNavigate } from "react-router-dom";

export default function AssessmentLoginPage() {
  const navigate = useNavigate();  // ← initialize navigate

  const [formData, setFormData] = useState({
    name: "",
    mobile: "",
    email: "",
    city: "",
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      await addDoc(collection(db, "assess"), {
        name: formData.name,
        mobile: formData.mobile,
        email: formData.email,
        city: formData.city,
        createdAt: Timestamp.now(),
      });
      setMessage("Registration successful! 🎉");
      setFormData({ name: "", mobile: "", email: "", city: "" });
      navigate("/assessmentt&c" );  // ← now works without error
    } catch (error) {
      console.error("Error adding document:", error);
      setMessage("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-md bg-white p-6 rounded-2xl shadow-lg"
      >
        <h2 className="text-2xl font-bold mb-6 text-center">
          Assessment Login
        </h2>
        <label className="block mb-4">
          <span className="text-gray-700">Full Name</span>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="mt-1 block w-full border rounded-lg p-2 focus:outline-none focus:ring-2"
            placeholder="John Doe"
          />
        </label>
        <label className="block mb-4">
          <span className="text-gray-700">Mobile Number</span>
          <input
            type="tel"
            name="mobile"
            value={formData.mobile}
            onChange={handleChange}
            required
            className="mt-1 block w-full border rounded-lg p-2 focus:outline-none focus:ring-2"
            placeholder="+91 9876543210"
          />
        </label>
        <label className="block mb-4">
          <span className="text-gray-700">Email Address</span>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="mt-1 block w-full border rounded-lg p-2 focus:outline-none focus:ring-2"
            placeholder="you@example.com"
          />
        </label>
        <label className="block mb-6">
          <span className="text-gray-700">Current City</span>
          <input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleChange}
            required
            className="mt-1 block w-full border rounded-lg p-2 focus:outline-none focus:ring-2"
            placeholder="Mumbai"
          />
        </label>
        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-red-700 disabled:opacity-50"
        >
          {loading ? "Submitting..." : "Login & Start Assessment"}
        </button>
        {message && (
          <p className="mt-4 text-center text-green-600">{message}</p>
        )}
      </form>
    </div>
  );
}
