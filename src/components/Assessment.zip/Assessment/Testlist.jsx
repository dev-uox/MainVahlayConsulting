import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function TestListPage() {
    
  const navigate = useNavigate();
  const tests = [
    { id: "listeningtest", title: "Listening Skills", duration: "15 min" },
    { id: "speakingtest", title: "Speaking Skills", duration: "10 min" },
    { id: "sellingtest", title: "Selling Skills", duration: "10 min" },
    { id: "problemsolvingtest", title: "Problem Solving Skills", duration: "10 min" },
    { id: "quick-aptitudetest", title: "Quick Aptitude", duration: "15 min" },
  ];

  // 60-minute global timer
  const GLOBAL_TOTAL = 60 * 60; // seconds
  const [globalLeft, setGlobalLeft] = useState(GLOBAL_TOTAL);

  useEffect(() => {
    const timer = setInterval(() => setGlobalLeft((t) => t - 1), 1000);
    return () => clearInterval(timer);
  }, []);

  // when global time expires, fire an event so each test can auto‐submit
  useEffect(() => {
    if (globalLeft <= 0) {
      window.dispatchEvent(new Event("globalTimeout"));
    }
  }, [globalLeft]);

  const formatTime = (secs) => {
    const m = String(Math.floor(secs / 60)).padStart(2, "0");
    const s = String(secs % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  const handleStart = (testId) => {
    navigate(`/${testId}`);
  };
  console.log(formdata)

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-4">
      {/* Global timer display */}
      <div className="mb-4 text-lg font-mono">
        Global Time Left: {formatTime(globalLeft)}
      </div>

      <h1 className="text-3xl font-bold mb-6">Select Your Test</h1>

      <div className="w-full max-w-2xl grid gap-6">
        {tests.map((test) => (
          <div
            key={test.id}
            className="flex items-center justify-between bg-white p-4 rounded-2xl shadow-md"
          >
            <div>
              <h2 className="text-xl font-semibold">{test.title}</h2>
              <p className="text-gray-500">Duration: {test.duration}</p>
            </div>
            <button
              onClick={() => handleStart(test.id)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
            >
              Start Test
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
