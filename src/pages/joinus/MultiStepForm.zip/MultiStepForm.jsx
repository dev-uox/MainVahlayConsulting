import React, { useState } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebaseConfig';

// Rest of the code remains the same...


const ApplicationForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    address: '',
    phone: '',
    email: '',
    position: '',
    dob: '',
    joiningDate: '',
    firstJob: '',
    nightShift: '',
    pressure: '',
    usSalesExperience: '',
    interestInPosition: '',
    resume: null,
    adharCardFront: null,
    adharCardBack: null,
    panCard: null,
    previousCompanyDoc: null,
    noPreviousDocReason: ''
  });

  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [noPreviousDoc, setNoPreviousDoc] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    const file = files[0];
    const maxFileSize = 5 * 1024 * 1024; // 5 MB

    if (file && file.size > maxFileSize) {
      alert('File size should not exceed 5 MB.');
      e.target.value = '';
      return;
    }

    if (name === 'resume' || name === 'previousCompanyDoc') {
      if (file && file.type !== 'application/pdf') {
        alert('Please upload PDF files only for resume and previous company document.');
        e.target.value = '';
        return;
      }
    } else if (name === 'adharCardFront' || name === 'adharCardBack' || name === 'panCard') {
      if (file && !file.type.startsWith('image/')) {
        alert('Please upload image files only for Aadhar Card and PAN Card.');
        e.target.value = '';
        return;
      }
    }
    setFormData({ ...formData, [name]: file });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();


    // Check if either document or reason is provided
  if (!formData.previousCompanyDoc && (!noPreviousDoc || !formData.noPreviousDocReason.trim())) {
    alert(
      "Please upload a document of the previous company or provide a reason if you don't have one."
    );
    return;
  }
  
    // Check form completion
    const isFormComplete = Object.values(formData).every(
      (value) => value !== '' && value !== null
    );
  
    if (!isFormComplete) {
      alert('Please fill out all fields and upload all necessary documents.');
      return;
    }
  
    if (!termsAccepted) {
      alert('Please accept the Terms and Conditions before submitting the form.');
      return;
    }
  
    setIsSubmitting(true);
  
    try {
      const uploadFileAndGetUrl = async (file, folder) => {
        const fileRef = ref(storage, `${folder}/${file.name}`);
        await uploadBytes(fileRef, file);
        return await getDownloadURL(fileRef);
      };
  
      // Upload each file and get URL
      const resumeUrl = formData.resume ? await uploadFileAndGetUrl(formData.resume, 'resumes') : '';
      const adharCardFrontUrl = formData.adharCardFront ? await uploadFileAndGetUrl(formData.adharCardFront, 'adharCards/front') : '';
      const adharCardBackUrl = formData.adharCardBack ? await uploadFileAndGetUrl(formData.adharCardBack, 'adharCards/back') : '';
      const panCardUrl = formData.panCard ? await uploadFileAndGetUrl(formData.panCard, 'panCards') : '';
      const previousCompanyDocUrl = formData.previousCompanyDoc && !noPreviousDoc ? await uploadFileAndGetUrl(formData.previousCompanyDoc, 'previousCompanyDocs') : '';
  
      // Create document in Firestore with URLs instead of File objects
      await addDoc(collection(db, 'jobApplications'), {
        firstName: formData.firstName,
        lastName: formData.lastName,
        address: formData.address,
        phone: formData.phone,
        email: formData.email,
        position: formData.position,
        dob: formData.dob,
        joiningDate: formData.joiningDate,
        firstJob: formData.firstJob,
        nightShift: formData.nightShift,
        pressure: formData.pressure,
        usSalesExperience: formData.usSalesExperience,
        interestInPosition: formData.interestInPosition,
        resumeUrl,
        adharCardFrontUrl,
        adharCardBackUrl,
        panCardUrl,
        previousCompanyDocUrl,
        noPreviousDocReason: noPreviousDoc ? formData.noPreviousDocReason : '',
      });
  
      alert('Form submitted successfully!');
      window.location.reload();
    } catch (error) {
      console.error('Error submitting the form:', error);
      alert(`An error occurred while submitting the form: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-3xl w-full">
        <h2 className="text-2xl font-bold text-center mb-8 text-gray-800">Job Application Form</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              placeholder="First Name"
              className="p-3 border rounded w-full"
              required
            />
            <input
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              placeholder="Last Name"
              className="p-3 border rounded w-full"
              required
            />
          </div>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email"
            className="p-3 border rounded w-full"
            required
          />
          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Phone Number"
            className="p-3 border rounded w-full"
            required
          />
          <textarea
            name="address"
            value={formData.address}
            onChange={handleChange}
            placeholder="Complete Address"
            className="p-3 border rounded w-full"
            rows="3"
            required
          />
          <select
            name="position"
            value={formData.position}
            onChange={handleChange}
            className="p-3 border rounded w-full"
            required
          >
            <option value="">Position Applying For</option>
            <option value="Tele Sales - Executive">Tele Sales - Executive</option>
            <option value="Customer Support">Customer Support</option>
            <option value="Backend Developer">Backend Developer</option>
            <option value="Frontend Developer">Frontend Developer</option>
            <option value="Data Assistants">Data Assistants</option>
          </select>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold mb-2">Date of Birth</label>
              <input
                type="date"
                name="dob"
                value={formData.dob}
                onChange={handleChange}
                className="p-3 border rounded w-full"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Preferred Joining Date</label>
              <select
                name="joiningDate"
                value={formData.joiningDate}
                onChange={handleChange}
                className="p-3 border rounded w-full"
                required
              >
                <option value="">Select Joining Date</option>
                <option value="8 November">8 November </option>
                <option value="12 November">12 November </option>
                <option value="13 November">13 November </option>
                <option value="14 November">14 November </option>
                <option value="18 November">18 November </option>
                <option value="20 November">20 November </option>
                <option value="21 November">21 November </option>
                <option value="25 November">25 November </option>
                <option value="27 November">27 November </option>
                <option value="28 November">28 November </option>
                <option value="5 December">5 December </option>
                <option value="11 December">11 December </option>
                <option value="12 December">12 December </option>
                <option value="13 December">13 December </option>
                <option value="18 December">18 December </option>
                <option value="23 December">23 December </option>
                <option value="27 December">27 December </option>
                {/* Add options for joining dates */}
              </select>
            </div>
          </div>
          {[
            { label: 'Is This Your First Job?', name: 'firstJob' },
            { label: 'Comfortable in Night Shift?', name: 'nightShift' },
            { label: 'Able to Work Under Pressure?', name: 'pressure' },
            { label: 'Experience in US/Canada Market?', name: 'usSalesExperience' }
          ].map((q) => (
            <div key={q.name} className="flex flex-col">
              <label className="text-sm font-semibold mb-2">{q.label}</label>
              <select
                name={q.name}
                value={formData[q.name]}
                onChange={handleChange}
                className="p-3 border rounded w-full"
                required
              >
                <option value="">Select</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>
          ))}
          <textarea
            name="interestInPosition"
            value={formData.interestInPosition}
            onChange={handleChange}
            placeholder="Why are you interested in this position?"
            className="p-3 border rounded w-full"
            rows="4"
            required
          />
          {[
            { label: 'Upload Resume', name: 'resume' },
            { label: 'Upload Aadhar Card - Front', name: 'adharCardFront' },
            { label: 'Upload Aadhar Card - Back', name: 'adharCardBack' },
            { label: 'Upload PAN Card', name: 'panCard' }
          ].map((fileField) => (
            <div key={fileField.name} className="flex flex-col">
              <label className="text-sm font-semibold mb-2">{fileField.label}</label>
              <input
                type="file"
                name={fileField.name}
                onChange={handleFileChange}
                className="p-3 border rounded w-full"
                required
              />
            </div>
          ))}
          <div className="flex flex-col">
  <label className="text-sm font-semibold mb-2">Document of Previous Company</label>
  <input
    type="file"
    name="previousCompanyDoc"
    onChange={handleFileChange}
    className="p-3 border rounded w-full"
    disabled={noPreviousDoc}
    required={!noPreviousDoc}
  />
  <div className="flex items-center mt-2">
    <input
      type="checkbox"
      checked={noPreviousDoc}
      onChange={() => {
        setNoPreviousDoc(!noPreviousDoc);
        setFormData({ ...formData, noPreviousDocReason: '' });
      }}
      className="mr-2"
    />
    <span>I don’t have a previous company document</span>
  </div>
  {noPreviousDoc && (
    <textarea
      name="noPreviousDocReason"
      value={formData.noPreviousDocReason}
      onChange={handleChange}
      placeholder="Please provide a reason"
      className="p-3 border rounded w-full mt-2"
      rows="3"
      required
    ></textarea>
  )}
</div>
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={termsAccepted}
              onChange={() => setTermsAccepted(!termsAccepted)}
              className="mr-2"
              required
            />
            <span>I accept the </span>
            <button
              type="button"
              onClick={() => setShowTermsModal(true)}
              className="text-blue-600 underline ml-1"
            >
              Terms and Conditions
            </button>
          </div>
          <button
            type="submit"
            className="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition disabled:opacity-50"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Application'}
          </button>
        </form>
        {showTermsModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-lg overflow-y-auto h-96">
              {/* Terms content */}

              <div className="text-black mb-4">
                <p><strong>Terms and Conditions</strong></p>
 
                <p>Dear Candidate,</p>
                <p>We are thrilled about the opportunity to have you join Vahlay Consulting Inc! Before we move forward with issuing your formal offer letter, please take the following important steps to ensure a                 smooth onboarding process.</p>
 
                <p><strong>Salary Revision:</strong> Your salary will be reviewed after 1 year from your last increment, or at such other time as the Management may decide. Salary revisions adiscretionary and                 based on effective performance. You may be asked to justify your salary by completing your monthly targets. The appraisal will be considered ashike in the CTC, and promotions will be based on                 one year of work. Both appraisals and promotions are at the Management's discretion.</p>
 
                <p><strong>Working Hours:</strong> Working hours will be from 07:00/08:00 PM to 05:00/06:00 AM, and may change as per Management's decision. The company typically operates six daa week, but you                 will work five days a week, with Sunday as your weekly off. You may be required to work on weekends when necessary, and shifts will be assigned your supervisor.</p>
 
                <p><strong>Absence/Leave Rule:</strong> If you are absent for a continuous period of 3 days without prior approval, or if you overstay on leave or training, it will lead automatic termination                 of your employment without notice. You will not be entitled to salary or benefits, and no claims for dues or compensation will be entertain</p>
 
                <p><strong>Probation/Confirmation:</strong> You will be on probation for three months. Based on your performance, your services may be confirmed in writing. During probation, yoservices can be                 terminated with seven days' notice on either side. After confirmation, the termination period extends to two months' notice on either side. Tprobation period may be extended at the Management’s                 discretion, and you will remain on probation until a confirmation order is issued. Once confirmed, you aexpected to work exclusively for the company, and you must seek written permission from                 the Board of Directors for any other work or public membership.</p>
 
                 <p><strong>Confidentiality:</strong> You are not allowed to publish any articles, statements, or make any communications related to the company’s products or matters without priwritten                 permission. Confidential information, including technical, commercial, or proprietary data, must not be disclosed during or after your employment unlerequired by law.</p>
 
                <p><strong>Intellectual Property:</strong> Any new methods or improvements developed by you during your employment will remain the sole property of the company. You must maintaconfidentiality                 regarding project documents, designs, cost estimations, software packages, company policies, and employee profiles. The use of personal USB drivand CDs within the organization is prohibited.</p>
 
                <p><strong>Responsibilities & Duties:</strong> You are required to adhere to the company’s rules and regulations and perform effectively to ensure desired results.</p>
 
                <p><strong>Past Records:</strong> If any information provided by you is found to be false, or if material information is suppressed, you may be removed from service without notice.</p>
 
                <p><strong>Notice Period:</strong> Upon confirmation, your appointment may be terminated by either party with two months' notice or two months' salary in lieu of the notice period. If you resign, the company may accept your resignation with immediate effect or up to the end of the notice period. The salary for the served notice period will be credited within 45 days of your last working day.</p>
 
                <p><strong>No Benefits if Leaving Without Notice:</strong> Employees leaving without serving the agreed notice period will not receive salary slips, experience letters, or any other formal documentation.</p>
 
                <p><strong>Termination of Employment:</strong> During probation, either party may terminate the employment with one week’s notice or salary in lieu thereof. After confirmation, termination requires one month's notice or salary in lieu thereof. Upon termination, all company property must be returned immediately, and no copies of company data should be retained. Violations of company rules or misconduct will result in immediate termination without notice, salary, or benefits.</p>
            </div>
              <button
                onClick={() => {
                  setTermsAccepted(true);
                  setShowTermsModal(false);
                }}
                className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition mr-2"
              >
                Accept
              </button>
              <button
                onClick={() => setShowTermsModal(false)}
                className="bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition"
              >
                Decline
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ApplicationForm;